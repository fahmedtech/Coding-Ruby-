#Faizan Ahmed
#Project 6
#Test GameOfThrones.rb class.

require './GameOfThrones'
require 'yaml'

#creating GameOfThrones character object.
got1 = GameOfThrones.new("Tyrion Lannister", 53, "M", "House Lannister", "Volantis")

#printing object to_string with array "got_object"
#got_object contains all 5 fields from got1 instance
got_object = [got1]
got_object.each do |x|
	print x.to_s, "\n\n"
end

#testing getters methods
print "GETTER TESTS: \n"
got_object = [got1]
got_object.each do |x|
	print x.character_name, "\n"
	print x.character_age, "\n"
	print x.character_gender, "\n"
	print x.house_of_allegiance, "\n"
	print x.location, "\n\n"
end

#testing setters methods (changing values)
print "SETTER TESTS: \n"
got_object = [got1]
got_object.each do |x|
	print "New Age: ", x.character_age = 37, "\n"
	print "Current New Location: ", x.location = "Winterfell", "\n\n"
end

#testing regular methods
got_object = [got1]
got_object.each do |x|
	print "Is char dead?  #{x.isCharDead?}\n"
	print x.rand_weapon, "\n\n"
end

#output the instance(array) to yaml format
STDOUT.print got_object.to_yaml







